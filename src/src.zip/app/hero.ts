export class Hero {
    id: number;
    name: string;
    "team": string;
    intelligence: number;
    strength: number;
    combat: number;
    pin: string;
}