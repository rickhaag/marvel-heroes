import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Hero, ApiHero } from './hero';

@Injectable({
  providedIn: 'root'
})
export class HeroService {

  private heroesUrl = 'api/heroes';
  private searchUrl = 'https://superhero-search.p.rapidapi.com';
  // private data = null;
  private h1data: any;
  // search: any = '';
  nameOrID: string = '';


  getHeroes(): Observable<Hero[]> {
    console.log('service');
    return this.http.get<Hero[]>(this.heroesUrl);
  }

  getHero(id: number): Observable<Hero> {
    const url = `${this.heroesUrl}/${id}`;
    return this.http.get<Hero>(url)
  }

  setScores(hero: Hero) {
    console.log(hero);
  }

  returnHero(search:string): Observable<object> {
    // console.log(search);
    const headers = {
                      "x-rapidapi-host": "superhero-search.p.rapidapi.com",
                      "x-rapidapi-key": "5174e80bc3mshbab39ed4e9891afp164a1djsndd99466c958d"
                    };
    // if (typeof(search) === 'number') {
    //   this.nameOrID = 'id';
    // } else if (typeof(search) === 'string') {
    //   this.nameOrID = 'hero';
    // };
    // console.log(this.nameOrID);
    // let hero = this.http.get<object>("https://superhero-search.p.rapidapi.com/?hero=spiderman",
    //   {headers});
    return this.http.get<object>('https://randomuser.me/api/');
      // console.log(user);
      // return user;
      // return hero;
    }
  

  // searchHero(): Observable<any> {
  //   return this.http.get('https://randomuser.me/api/');
  //       // console.log('past http')
  //   }

// searchHero() {
//   let hdata: any;
//   const headers:any = { 
//               "x-rapidapi-host": "superhero-search.p.rapidapi.com",
//               "x-rapidapi-key": "5174e80bc3mshbab39ed4e9891afp164a1djsndd99466c958d"
//             };
//   console.log(headers);
//   this.http.get<any>("https://superhero-search.p.rapidapi.com/?hero=spiderman",  {headers})
//   .subscribe( hdata => console.log(hdata) )
//   , error => console.error('error ', error);
// }

 

  constructor(private http: HttpClient) { }
}

