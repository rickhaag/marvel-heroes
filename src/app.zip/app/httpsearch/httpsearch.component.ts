import { Component, OnInit } from '@angular/core';
import { HeroService } from '../hero.service';


@Component({
  selector: 'app-httpsearch',
  templateUrl: './httpsearch.component.html',
  styleUrls: ['./httpsearch.component.css']
})
export class HttpsearchComponent implements OnInit {

searchParam: any = '';
returnedHero: any = {};
searched = false;

// {id: 0, name: '', team: '', intelligence:0,strength:0,combat:0,pin:''};

  search() {
    this.searched = true;
    this.heroService.returnHero(this.searchParam).subscribe(data => this.returnedHero = data);
    console.log(this.returnedHero);
  }

  constructor(private heroService: HeroService) { }

  ngOnInit() {
  }

}
